<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'search'        => 'Search',
    'more_reading'  => 'les plus lus',
    'posts'         => 'Des articles',
    'follow'        => 'Suivez-nous sur',
    'News'          => 'nouvelles',
    'reports'          => 'Rapports',
    'press'          => 'Économie',
    'interview'          => 'entretiens',
    'openioun'          => 'Articles de rayons',
    'sport'          => 'sport',
    'mix'          => 'Mélanger',
    'Most_Read_Week' => 'Semaine la plus lue',
    'search' => 'chercher',
    'Categories' => 'Catégories',
    'Follow_Us' => 'Suivez nous',
    'other_posts' => 'autres messages',
    'Videos' => 'Vidéos',
     'photo' => ' Ville de Zouérate'
    

];

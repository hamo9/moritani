@include('frontEnd.layout.header')
@include('frontEnd.layout.navbar')
    <!-- top bar -->


    @yield('content')


@include('frontEnd.layout.footer')


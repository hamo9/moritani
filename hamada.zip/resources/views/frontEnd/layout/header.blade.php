<!DOCTYPE html>
@if (App::getLocale() == 'fr')
    <html lang="en">
@else
    <html lang="ar" dir="rtl">
@endif


<head>
    <base href="/public">
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="@yield('desc')" />
    <meta name="author" content="" />
    <title>
        تيرس اينفو
        | 
        @yield('title')
    </title>
    <!-- Favicon-->
    <link href="{{ asset('assets/frontEnd/img/logo.png') }}" rel="icon">
    <!-- Core theme CSS (includes Bootstrap)-->



    <link href="assets/frontEnd/css/myStyle.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">

    {{-- arb --}}
    @if (App::getLocale() == 'fr')
        <link href="assets/frontEnd/css/styles.css" rel="stylesheet" />
        @else
        <link href="assets/frontEnd/css/bootstrap_rtl.css" rel="stylesheet" />
        <link href="assets/frontEnd/css/styles.css" rel="stylesheet" />
        <link href="assets/frontEnd/css/rtl.css" rel="stylesheet" />

    @endif
    {{-- end arb --}}
    
    
<style>
    body{
      font-family: 'Amiri', serif !important;
    }
</style>




</head>

 @yield('content')


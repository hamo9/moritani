<div class="card card-body pt-1 mix_section mt-4 MyHover">
    <div class="row card_title">
        <div class="col-6">
            <h4><?php echo e(__('welcome.mix')); ?></h4>
        </div>

        <div class="col-6 text-end btn_controller_slider">
            <button><i class="bi bi-chevron-right" data-bs-target="#carouselExampleControls_mix"
                    data-bs-slide="next"></i>
            </button>
            <button><i class="bi bi-chevron-left" data-bs-target="#carouselExampleControls_mix" data-bs-slide="prev"></i>
            </button>
        </div>

    </div>

    <!-- ====================-->

    <?php if($chunk_mix->count() > 0): ?>
        <div id="carouselExampleControls_mix" class="carousel slide" data-bs-ride="carousel" data-bs-interval="false">
            <div class="carousel-inner repoerts_carousel">


                <?php for($x = 0; $x < $chunk_mix->count(); $x++): ?>
                    <div class="carousel-item">
                        <div class="row mt-2 card_small_reports">
                            <?php
                                $number = 0;
                            ?>

                            <?php $__currentLoopData = $chunk_mix[$x]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $number = ++$number;
                                ?>

                                <?php if($number == 1): ?>
                                    <div class="col-md-6">
                                        <a href="<?php echo e(route('post.frontEnd', $item->id)); ?>"
                                            class="main_post_for_mix mb-4"
                                            style="background-image: url('assets/images/<?php echo e($item->photo); ?>');">
                                            <div class="overray"></div>
                                            <div class="post_content">
                                                <h6 class="mb-4">
                                                    <?php echo e(\Carbon\Carbon::parse($item->created_at)->diffForhumans()); ?>

                                                </h6>
                                                <h3>
                                                    <?php
                                                        $val = substr($item->body, 0, 100);
                                                    ?>

                                                    <?php echo e($val); ?> ....
                                                </h3>
                                            </div>
                                        </a>

                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <div class="col-md-6">
                                <?php
                                    $number = 0;
                                ?>
                                <?php $__currentLoopData = $chunk_mix[$x]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $number = ++$number;
                                    ?>

                                    <?php if($number > 1): ?>
                                        <div class="col-12 row mb-4">
                                            <div class="col-5">
                                                <div class="img_for_news"
                                                    style="background-image: url('assets/images/<?php echo e($item->photo); ?>')">
                                                </div>
                                            </div>
                                            <div class="col-7">
                                                <div class="small_text mt-1"> <i
                                                        class="bi bi-clock"></i><?php echo e(\Carbon\Carbon::parse($item->created_at)->diffForhumans()); ?>

                                                </div>
                                                <h6><?php echo e($item->title); ?></h6>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>


                        </div>
                    </div>
                <?php endfor; ?>

            </div>

        </div>
    <?php else: ?>
        <img class="img-fluid mt-3 mb-3" src="<?php echo e(asset('assets/frontEnd/img/empty.svg')); ?>" alt="">
    <?php endif; ?>


    <!-- ========================= -->


</div>


<div class="card card-body pt-1 mix_section mt-4 MyHover">
    <div class="row card_title">
        <div class="col-6">
            <h4><?php echo e(__('welcome.photo')); ?> </h4>
        </div>

        <div class="col-6 text-end btn_controller_slider">
            <button><i class="bi bi-chevron-right" data-bs-target="#carouselExampleControls_photo"
                    data-bs-slide="next"></i>
            </button>
            <button><i class="bi bi-chevron-left" data-bs-target="#carouselExampleControls_photo" data-bs-slide="prev"></i>
            </button>
        </div>

    </div>

    <!-- ====================-->


    <div id="carouselExampleControls_photo" class="carousel slide" data-bs-ride="carousel" >
        <div class="carousel-inner repoerts_carousel">


                     <div class="carousel-item active">
                        <img src="assets/img/PSX_20220426_220149.jpg" class="d-block w-100" alt="...">
                      </div>
                      <div class="carousel-item">
                        <img src="assets/img/PSX_20220426_220442.jpg" class="d-block w-100" alt="...">
                      </div>
                      <div class="carousel-item">
                        <img src="assets/img/PSX_20220426_221011.jpg" class="d-block w-100" alt="...">
                      </div>
                      <div class="carousel-item">
                        <img src="assets/img/PSX_20220426_221208.jpg" class="d-block w-100" alt="...">
                      </div>


        </div>

    </div>


    <!-- ========================= -->


</div>

<?php /**PATH /home/tir8922/public_html/resources/views/frontEnd/layout/mix.blade.php ENDPATH**/ ?>
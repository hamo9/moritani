<div class="container main-container">
    <div class="hero mt-4">

        <?php if($LastPosts->count() > 0): ?>
            <div class="row p-md-0">

                <?php
                    $number = 0;
                    $number2 = 0;

                ?>

                <?php $__currentLoopData = $LastPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $number = ++$number;
                    ?>

                    <?php if($number == 1): ?>
                        <a href="<?php echo e(route('post.frontEnd',$item->id)); ?>" class="col-md-6 p-md-0">
                            <div class="for_new_post"
                        style="background-image: url('assets/images/<?php echo e($item->photo); ?>');">
                                <div class="overray"></div>
                                <div class="post_content">
                                    <h6 class="mb-4"><?php echo e(\Carbon\Carbon::parse($item->created_at)->diffForhumans()); ?></h6>
                                    <h3>
                                        <?php echo e($item->title); ?>

                                    </h3>
                                </div>
                            </div>
                        </a>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <div class="col-md-6">
                    <div class="row pt-2 pt-md-0 p-2 p-md-0">
                        <?php $__currentLoopData = $LastPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $number2 = ++$number2;
                            ?>


                                    <?php if($number2 > 1): ?>
                                        <a href="<?php echo e(route('post.frontEnd',$item->id)); ?>" class="col-6 box_for_new_post_small">
                                            <div class="for_new_post_small"
                                            style="background-image: url('assets/images/<?php echo e($item->photo); ?>');">
                                                <div class="overray"></div>
                                                <div class="post_content">
                                                    <p><?php echo e(\Carbon\Carbon::parse($item->created_at)->diffForhumans()); ?></p>
                                                    <h6>
                                                        <?php echo e($item->title); ?>

                                                    </h6>
                                                </div>
                                            </div>
                                        </a>
                                    <?php endif; ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>

        <?php endif; ?>
    </div>
</div>
<?php /**PATH /home/tir8922/public_html/resources/views/frontEnd/layout/hero.blade.php ENDPATH**/ ?>
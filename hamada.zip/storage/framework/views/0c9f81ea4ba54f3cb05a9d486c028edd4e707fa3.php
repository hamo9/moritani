<div class="col-12 the_press_section mb-3">
    <div class="card card-body MyHover_blue">
        <div class="row card_title">
            <div class="col-6">
                <h4><?php echo e(__('welcome.Videos')); ?></h4>
            </div>

            <div class="col-6 text-end btn_controller_slider">
                <button><i class="bi bi-chevron-right" data-bs-target="#carouselExampleControls_videos"
                        data-bs-slide="next"></i>
                </button>
                <button><i class="bi bi-chevron-left" data-bs-target="#carouselExampleControls_videos"
                        data-bs-slide="prev"></i>
                </button>
            </div>

        </div>

        <?php if($chunk_vedios->count() > 0): ?>
            <div id="carouselExampleControls_videos" class="carousel slide" data-bs-ride="carousel"
                data-bs-interval="false">
                <div class="carousel-inner repoerts_carousel">


                    <?php for($x = 0; $x < $chunk_vedios->count(); $x++): ?>
                        <div class="carousel-item">
                            <div class="row mt-2 card_small_reports">

                                <?php $__currentLoopData = $chunk_vedios[$x]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-6">

                                        <video controls class="my_box_img" style="height:200px; width:100%;">
                                            <source src="<?php echo e(asset('/assets/images/' . $item->video)); ?>"
                                                type="video/mp4">
                                        </video>

                                        <h6 class="mt-2">

                                            <a
                                                href="<?php echo e(route('video.frontEnd', $item->id)); ?>"><?php echo e($item->title); ?></a>
                                        </h6>
                                        <div class="date mb-1 mt-1 small_text">
                                            <i class="bi bi-clock"></i>
                                            <span><?php echo e($item->created_at); ?></span>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    <?php endfor; ?>
                </div>
            </div>
        <?php else: ?>
        <img class="img-fluid mt-3 mb-3" src="<?php echo e(asset('assets/frontEnd/img/empty.svg')); ?>" alt="">
        <?php endif; ?>






    </div>

</div>
<?php /**PATH /home/tir8922/public_html/resources/views/frontEnd/layout/videos.blade.php ENDPATH**/ ?>
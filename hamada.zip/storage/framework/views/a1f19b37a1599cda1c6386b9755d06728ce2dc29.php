<div class="the_press_section">
    <div class="card card-body ">
        <h5><?php echo e(__('welcome.Follow_Us')); ?></h5>
        <div class="row social_follow mt-4">
            <a href="https://www.facebook.com/TirisInfo" class="col-3 text-dark">
                <i class="bi bi-facebook"></i>
            </a>
            <a href="http://wa.me/+22237457974" class="col-3 text-dark">
                <i class="bi bi-whatsapp"></i>
            </a>
            <a href="https://youtube.com/channel/UCSrQNBZLLx20GGzl5fwlAAw" class="text-dark col-3">
                <i class="bi bi-youtube"></i>
            </a>
            <a class="col-3 text-dark">
                <i class="bi bi-twitter"></i>
            </a>
        </div>


    </div>
</div>
<?php /**PATH D:\programming 2022\php\laravel blog\Blog\blog_v_3\resources\views/frontEnd/layout/follow.blade.php ENDPATH**/ ?>
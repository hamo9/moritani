<?php echo $__env->make('frontEnd.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>

    
    <?php echo $__env->make('frontEnd.layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!-- start hero section -->
    <?php echo $__env->make('frontEnd.layout.hero', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End hero section -->

    <!-- start main section -->
    <div class="container p-md-0 mt-4">
        <div class="row p-0">

            <div class="col-md-8 mb-4">
                <!-- start news section -->
                <?php echo $__env->make('frontEnd.layout.news', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <!-- end news section -->

                <!-- advertisement widget-->
                <div class="card mb-4 col-12">
                    <div class="card-body text-center">
                        <img src="<?php echo e(asset('/assets/images/' . $ads[0]->photo)); ?>" class="img-fluid" alt="">
                    </div>
                </div>

                <!-- start reports section -->
                <?php echo $__env->make('frontEnd.layout.reports', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- start reports section -->

                <!-- End reports section -->


                <div class="row mt-4">
                    <!-- start the press section -->
                    <?php echo $__env->make('frontEnd.layout.press', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



                    <!-- start Figures section -->
                    <?php echo $__env->make('frontEnd.layout.figures', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    
                     <!-- start videos section -->
                    <?php echo $__env->make('frontEnd.layout.videos', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



                </div>


                <!-- Start opinion section -->
                <?php echo $__env->make('frontEnd.layout.opinion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                <!-- advertisement widget-->
                <div class="card mb-4 col-12 mt-3">
                    <div class="card-body text-center">
                        <img src="<?php echo e(asset('/assets/images/' . $ads[1]->photo)); ?>" class="img-fluid" alt="">
                    </div>
                </div>

                <!-- start sports section -->
                <?php echo $__env->make('frontEnd.layout.sports', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                <!-- End sports section -->

                <!-- start Mix section -->
                <?php echo $__env->make('frontEnd.layout.mix', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <!-- End Mix section -->


            </div>


            <div class="col-md-4">
               <!-- Search widget-->
               <div class="card mb-4">
                <div class="card-header"><?php echo e(__('welcome.search')); ?></div>
                <div class="card-body">
                <form action="<?php echo e(route('search.frontEnd')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                        <div class="input-group">
                            <input class="form-control form-control-lg" type="text" placeholder="Enter search term..."
                                aria-label="Enter search term..." aria-describedby="button-search"  name="search" />
                            <button class="btn btn-primary" id="button-search" type="button">Go!</button>
                        </div>
                    </form>
                </div>
            </div>
                <!-- advertisement widget-->
                <div class="card mb-4">
                    <div class="card-body text-center">
                        <img src="<?php echo e(asset('/assets/images/' . $ads[2]->photo)); ?>" class="img-fluid" alt="">
                    </div>
                </div>

                <!-- Categories widget-->
                <div class="card mb-4">
                    <div class="card-header">Categories</div>
                    <div class="card-body">
                        <div class="row">
                            <?php if(isset($categories)): ?>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-sm-6">
                                        <ul class="list-unstyled mb-0">
                                        <li><a href="<?php echo e(route('category_posts.frontEnd',$category->id)); ?>"><?php echo e($category->name); ?></a></li>
                                        </ul>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                        </div>
                    </div>
                </div>

                <!-- for Most Read of the Week widget-->
                <?php echo $__env->make('frontEnd.layout.read_week', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                <!-- start Economie section -->
                <?php echo $__env->make('frontEnd.layout.economie', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                <!-- start Society section -->
                <?php echo $__env->make('frontEnd.layout.society', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                <!-- for Most Read widget-->
                <?php echo $__env->make('frontEnd.layout.most_read', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                <!-- start Economie section -->
                <?php echo $__env->make('frontEnd.layout.follow', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            </div>
        </div>
    </div>

    <?php echo $__env->make('frontEnd.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH /home/tir8922/public_html/resources/views/frontEnd/welcome.blade.php ENDPATH**/ ?>
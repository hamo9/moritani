<!DOCTYPE html>
<?php if(App::getLocale() == 'fr'): ?>
    <html lang="en">
<?php else: ?>
    <html lang="ar" dir="rtl">
<?php endif; ?>


<head>
    <base href="/public">
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="<?php echo $__env->yieldContent('desc'); ?>" />
    <meta name="author" content="" />
    <title>
        تيرس اينفو
        | 
        <?php echo $__env->yieldContent('title'); ?>
    </title>
    <!-- Favicon-->
    <link href="<?php echo e(asset('assets/frontEnd/img/logo.png')); ?>" rel="icon">
    <!-- Core theme CSS (includes Bootstrap)-->



    <link href="assets/frontEnd/css/myStyle.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">

    
    <?php if(App::getLocale() == 'fr'): ?>
        <link href="assets/frontEnd/css/styles.css" rel="stylesheet" />
        <?php else: ?>
        <link href="assets/frontEnd/css/bootstrap_rtl.css" rel="stylesheet" />
        <link href="assets/frontEnd/css/styles.css" rel="stylesheet" />
        <link href="assets/frontEnd/css/rtl.css" rel="stylesheet" />

    <?php endif; ?>
    
    
    
<style>
    body{
      font-family: 'Amiri', serif !important;
    }
</style>




</head>

 <?php echo $__env->yieldContent('content'); ?>

<?php /**PATH /home/tir8922/public_html/resources/views/frontEnd/layout/header.blade.php ENDPATH**/ ?>
<?php echo $__env->make('frontEnd.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>

    
    <?php echo $__env->make('frontEnd.layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="mt-3 mb-3">
        <div class="text-center">
            <img src="<?php echo e(asset('/assets/images/' . $ads->photo)); ?>" class="img-fluid" alt="">
        </div>
    </div>


    <div class="container p-md-0 mt-4 mb-5 mt-4">
        <div class="row p-0">

            <div class="col-md-8 mb-4">

                <!-- start category posts -->
                <div class="card mb-3 shadow">
                    <div class="card-header">
                        <h4>
                            <?php echo e(__('welcome.posts')); ?> <?php echo e($category->name); ?>

                        </h4>
                    </div>
                    <div class="card-body">


                        <?php if(isset($category->posts)): ?>
                            <?php $__currentLoopData = $category->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(route('post.frontEnd', $post->id)); ?>" class="text-dark row mt-4">
                                    <div class="col-md-6">
                                        <div class="img_category_posts"
                                            style="background-image:url('assets/images/<?php echo e($post->photo); ?>')"></div>
                                    </div>
                                    <div class="col-md-6">
                                        <p class="small_text"><i
                                                class="bi bi-clock p-1"></i><?php echo e(\Carbon\Carbon::parse($post->created_at)->diffForhumans()); ?>

                                        </p>
                                        <h4><?php echo e($post->title); ?></h4>
                                        <p>
                                            <?php echo e(substr($post->body, 0, 150)); ?> ...
                                        </p>

                                    </div>

                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>




                    </div>

                </div>
                <!-- end main post -->



            </div>

            <div class="col-md-4">


                <!-- for Most Read widget-->
                <div class="card mb-4">
                    <div class="card-body">

                        <div class="row card_title">
                            <div class="col-8">
                                <h5 class="text-success"><?php echo e(__('welcome.more_reading')); ?></h5>
                            </div>

                        </div>

                        <hr>
                        <?php
                            $myNumber = 0;
                        ?>

                        <?php if(isset($chunk_most_read)): ?>
                            <?php $__currentLoopData = $chunk_most_read; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(route('post.frontEnd', $item->id)); ?>" class="text-dark row mb-2 mt-4">
                                    <div class="col-6 most_read_count">
                                        <div class="most_read_count_1"><?php echo e(++$myNumber); ?></div>
                                        <div class="my_box_img_small"
                                            style="background-image: url('assets/images/<?php echo e($item->photo); ?>');">
                                        </div>
                                    </div>
                                    <div class="col-6 p-0">
                                        <p><?php echo e($item->title); ?></p>
                                        <p class="small_text"><i
                                                class="bi bi-clock"></i><?php echo e(\Carbon\Carbon::parse($item->created_at)->diffForhumans()); ?>

                                        </p>
                                    </div>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                    </div>


                </div>

                <!-- start Follow section -->
                <div class="the_press_section mt-4">
                    <div class="card card-body ">
                        <h5><?php echo e(__('welcome.follow')); ?></h5>
                        <div class="row social_follow mt-4">
                            <div class="col-3">
                                <i class="bi bi-facebook"></i>
                            </div>
                            <div class="col-3">
                                <i class="bi bi-whatsapp"></i>
                            </div>
                            <div class="col-3">
                                <i class="bi bi-youtube"></i>
                            </div>
                            <div class="col-3">
                                <i class="bi bi-twitter"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php echo $__env->make('frontEnd.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\programming 2022\php\laravel blog\Blog\blog_v_3\resources\views/frontEnd/category_posts.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title'); ?>
    اضافه مورد
<?php $__env->stopSection(); ?>




<?php $__env->startSection('content'); ?>
    <div class="container-fluid">

        <div class="mb-2">
            <a href="<?php echo e(route('categories.index')); ?>" class="btn btn-danger">رجوع</a>
        </div>

        <div class="card shadow">
            <div class="card-header">
                <h5>إضافة قسم جديد</h5>
            </div>
            <div class="card-body">

                <form action="<?php echo e(route('categories.update',$category->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>

                    <div class="row">

                        <input type="hidden" class="id" name="id" value="<?php echo e($category->id); ?>">


                
                        <div class="col-md-6">
                            <div class="form-group mb-2 mt-0 pt-0">
                                <label for="">اسم القسم بالعربي</label>
                                <input class="form-control" type="text" name="name_ar" id="" value="<?php echo e($category->getTranslation('name','ar')); ?>">
                                <?php $__errorArgs = ['name_ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        
                        <div class="col-md-6">
                            <div class="form-group mb-2 mt-0 pt-0">
                                <label for="">اسم القسم بالفرنسي</label>
                                <input class="form-control" type="text" name="name_fr" value="<?php echo e($category->getTranslation('name','fr')); ?>">
                                <?php $__errorArgs = ['name_fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>






                        <div class="col-12 mt-4">
                            <button class="btn btn-primary">حفظ</button>
                            <button class="btn btn-dark mr-2">اعادة تعيين</button>

                        </div>
                    </div>
                </form>




            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tir8922/public_html/resources/views/admin/categories/edit.blade.php ENDPATH**/ ?>